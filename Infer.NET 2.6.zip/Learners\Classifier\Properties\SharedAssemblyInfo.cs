﻿/********************************************************
*                                                       *
*   Copyright (C) Microsoft. All rights reserved.       *
*                                                       *
********************************************************/

using System.Reflection;

#if DEBUG
[assembly: AssemblyConfiguration("Debug")]
#else
[assembly: AssemblyConfiguration("Release")]
#endif
[assembly: AssemblyCompany("Microsoft Research Limited")]
[assembly: AssemblyProduct("MicrosoftResearch.Infer")]
[assembly: AssemblyCopyright("Copyright © Microsoft Research Limited 2008-2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]