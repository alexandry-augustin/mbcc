#light
namespace Microsoft.FSharp
open System.Reflection 

[<assembly: AssemblyVersion("2.6.41114.1")>]
[<assembly: AssemblyFileVersion("2.6.41114.1")>]
do()
