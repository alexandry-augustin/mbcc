// (C) Copyright 2008 Microsoft Research Cambridge

[assembly:
    System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Scope = "member",
        Target =
            "MicrosoftResearch.Infer.Distributions.DistributionCursorArray.ProjectTo(System.Int32[],MicrosoftResearch.Infer.Distributions.DistributionCursorArray,MicrosoftResearch.Infer.Action,MicrosoftResearch.Infer.Action):System.Void"
        , MessageId = "d1")]
[assembly:
    System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Scope = "member",
        Target =
            "MicrosoftResearch.Infer.Distributions.DistributionCursorArray.ProjectTo(System.Int32[],MicrosoftResearch.Infer.Distributions.DistributionCursorArray,MicrosoftResearch.Infer.Action,MicrosoftResearch.Infer.Action):System.Void"
        , MessageId = "d2")]
[assembly:
    System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", Scope = "member",
        Target = "MicrosoftResearch.Infer.Distributions.Wishart..ctor(MicrosoftResearch.Infer.Matrix,MicrosoftResearch.Infer.Vector)", MessageId = "0#")]
[assembly:
    System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", Scope = "member",
        Target = "MicrosoftResearch.Infer.Distributions.Wishart..ctor(MicrosoftResearch.Infer.Matrix,MicrosoftResearch.Infer.Vector,System.Double[],System.Int32)",
        MessageId = "0#")]
[assembly:
    System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", Scope = "member",
        Target = "MicrosoftResearch.Infer.Distributions.VectorGaussian..ctor(MicrosoftResearch.Infer.Vector,MicrosoftResearch.Infer.Matrix)", MessageId = "1#")]
[assembly:
    System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1709:IdentifiersShouldBeCasedCorrectly", Scope = "member",
        Target = "MicrosoftResearch.Infer.Distributions.VectorGaussian..ctor(MicrosoftResearch.Infer.Vector,MicrosoftResearch.Infer.Matrix,System.Double[],System.Int32)",
        MessageId = "1#")]
[assembly:
    System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1804:RemoveUnusedLocals", Scope = "member",
        Target =
            "MicrosoftResearch.Infer.Distributions.DistributionCursorArray.ProjectTo(MicrosoftResearch.Infer.Distributions.IDistribution,MicrosoftResearch.Infer.Action,MicrosoftResearch.Infer.Action):System.Void"
        , MessageId = "d")]
