﻿#light
namespace TestFSharp
open System.Reflection
[<assembly:AssemblyTitle("TestFSharp.exe")>]
[<assembly:AssemblyDescription("Infer.NET F# Test Application")>]
[<assembly:AssemblyConfiguration("")>]
[<assembly:AssemblyCompany("Microsoft Research Limited")>]
[<assembly:AssemblyProduct("MicrosoftResearch.Infer")>]
[<assembly: AssemblyCopyright("Copyright (C) Microsoft Research Limited 2008-2014")>]
[<assembly: AssemblyTrademark("")>]
[<assembly: AssemblyCulture("")>]
do()

